//
//  ScrollViewController.swift
//  IntenrProject
//
//  Created by Zafar Ahmad on 01/10/19.
//  Copyright © 2019 Zafar Ahmad. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ScrollViewController: UIViewController, UITextFieldDelegate {

    let ApiURL = "http://flairvapor.com/api.attendance.com/v/index.php"
    
    var user_name : String!
    var user_email: String!
    var user_password: String!
    var user_phone_No: String!
    
    var company_name : String!
    var company_email: String!
    var company_registration_no: String!
    var company_phone_no: String!
    var company_addres: String!
    var company_image: String!
    
    
    
    @IBOutlet weak var CompanyRegistrationForm: UILabel!
    
    @IBOutlet weak var CompanyLOGO: UIImageView!
    
    
    @IBOutlet weak var scroolView: UIScrollView!
    
    @IBOutlet weak var UserDetailsLabel: UILabel!
    
    @IBOutlet weak var UserNameTextField: UITextField!
    @IBOutlet weak var UserEmailTextField: UITextField!
    @IBOutlet weak var UserPasswordTextField: UITextField!
    @IBOutlet weak var UserCOnfirmPasswordTextField: UITextField!
    @IBOutlet weak var UserPhoneNumberTextField: UITextField!
    
    @IBOutlet weak var CompanyDetailsPhoneNumber: UILabel!
    
    @IBOutlet weak var CompanyName: UITextField!
    @IBOutlet weak var CompanyEmail: UITextField!
    @IBOutlet weak var CompanyRegistrationNumber: UITextField!
    @IBOutlet weak var CompanyPhoneNuber: UITextField!
    @IBOutlet weak var CompanyAddressTextField: UITextField!
    
    @IBOutlet weak var SubmitButton: UIButton!
    
    //@IBOutlet weak var Backbutton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollViewDidScroll(scrollView: scroolView)
        scroolView.isDirectionalLockEnabled = true
       // textFieldShouldReturn(UserNameTextField)
      //  textFieldShouldReturn(UserPasswordTextField)
        textFieldShouldReturn(UserPhoneNumberTextField)
        textFieldShouldReturn(CompanyPhoneNuber)
        navigationItem.leftBarButtonItem?.isEnabled = true
        
        
        UserNameTextField.delegate = self
//        self.UserNameTextField.markedTextRange
        UserPasswordTextField.delegate = self
        UserPhoneNumberTextField.delegate = self
        UserPhoneNumberTextField.textContentType = .telephoneNumber
        // Do any additional setup after loading the view.
        CompanyLOGO.isUserInteractionEnabled = true
        CompanyLOGO.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(CompanyLogo)))
        
        CompanyLOGO.layer.borderWidth = 0.5
        CompanyLOGO.layer.masksToBounds = false
        CompanyLOGO.layer.borderColor = UIColor.lightGray.cgColor
        CompanyLOGO.layer.cornerRadius = CompanyLOGO.frame.size.width/2
        CompanyLOGO.clipsToBounds = true
        
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        CompanyAddressTextField.delegate = self
        UserNameTextField.delegate = self
        UserPasswordTextField.delegate = self
        UserCOnfirmPasswordTextField.delegate = self
        UserPhoneNumberTextField.delegate = self
        CompanyName.delegate = self
        CompanyEmail.delegate = self
        CompanyRegistrationNumber.delegate = self
        CompanyPhoneNuber.delegate = self
        CompanyAddressTextField.delegate = self
        

    }
    
//    
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        navigationController?.setNavigationBarHidden(true, animated: animated)
//    }
//    
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        navigationController?.setNavigationBarHidden(false, animated: animated)
//    }
    
    
    @objc func CompanyLogo() {
        let picker = UIImagePickerController()
        picker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
        //picker.delegate = self
        picker.allowsEditing = true
        
    }
    
    @IBAction func submitButton(_ sender: Any) {
        
//         let user_name = UserNameTextField.text, let user_email = UserEmailTextField.text, let user_pas = UserPasswordTextField.text, let user_phone_No = UserPhoneNumberTextField.text, company_name = CompanyName.text, company_email = CompanyEmail.text, company_registration_no = CompanyRegistrationNumber.text, }
        
        user_name = UserNameTextField.text
        user_email = UserEmailTextField.text
        user_password = UserPasswordTextField.text
        user_phone_No = UserPhoneNumberTextField.text
        company_name = CompanyName.text
        company_email = CompanyEmail.text
        company_registration_no = CompanyRegistrationNumber.text
        company_phone_no = CompanyPhoneNuber.text
        company_addres = CompanyAddressTextField.text
      //  company_image = String(CompanyLOGO.image)
      
        getURl(url: ApiURL)
        
        putData(usrName: user_name, userEmail: user_email, userPassword: user_password, userphoneno: user_phone_No, companyName: company_name, companyEmail: company_email, companyegistrationNo: company_registration_no, companyPhoneNo: company_phone_no, companyAddress: company_addres)
        
        
    }
    
 
}

func scrollViewDidScroll(scrollView: UIScrollView) {
    if scrollView.contentOffset.x>0 {
        scrollView.contentOffset.x = 0
    }
}

extension ScrollViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        var image : UIImage?
        if let editedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            image = editedImage
        }
        if let OriginalImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            image = OriginalImage
        }
        
        if let userSelectedImage = image {
            CompanyLOGO.image = userSelectedImage
            print("the image is Selected")
        }
        dismiss(animated: true, completion: nil)
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
            textField.resignFirstResponder()
       return true
    
    }
    
    func putData(usrName : String, userEmail : String, userPassword : String, userphoneno: String, companyName: String, companyEmail: String, companyegistrationNo: String, companyPhoneNo: String, companyAddress: String) {
        
        Alamofire.request(ApiURL, method: .post,parameters:["clientKey":"clientKey","accessToken":"accessTokenValue","action": "company_registration", "requestData":["userDetails":["userName": user_name,"userEmail": user_email,"userPassword": user_password,"userPhone": user_phone_No]], "company_detail": ["companyName": company_name as Any, "companyEmail": company_email as Any, "companyRegistration_no": company_registration_no as Any, "companyPhone": company_phone_no as Any, "companyAddress": company_addres as Any]], encoding: JSONEncoding.default, headers: nil).responseJSON { (responce) in
            
            if responce.result.isSuccess {
                let getJason : JSON = JSON(responce.result.value!)
                print("we've got the registration")
                print(getJason)
            }
            
        }
        
    }
    
    
    func getURl(url: String) {
        
        Alamofire.request(url, method: .post).responseJSON { (response) in
            
            if response.result.isSuccess {
                let ApiResponse : JSON = JSON(response.result.value!)
                print(ApiResponse)
            }
            else {
                print("No Response From the server")
            }
            
        }
        
    }


}

