//
//  thirdViewController.swift
//  IntenrProject
//
//  Created by Zafar Ahmad on 30/09/19.
//  Copyright © 2019 Zafar Ahmad. All rights reserved.
//

import UIKit

class thirdViewController: UIViewController {

    var data = ""
    @IBOutlet weak var logoim: UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var settingIcon: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logoim.layer.borderWidth = 0.5
        logoim.layer.masksToBounds = false
        logoim.layer.borderColor = UIColor.lightGray.cgColor
        logoim.layer.cornerRadius = logoim.frame.size.width/2
        logoim.clipsToBounds = true
        
        
        settingIcon.layer.borderWidth = 0.5
        settingIcon.layer.masksToBounds = false
        settingIcon.layer.borderColor = UIColor.lightGray.cgColor
        settingIcon.layer.cornerRadius = settingIcon.frame.size.width/2
        settingIcon.clipsToBounds = true
        
        settingIcon.isUserInteractionEnabled = true
        settingIcon.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(settings)))
        
        
        
        //label.text = data
        
        // Do any additional setup after loading the view.
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
    
    
    @objc func settings() {
        
        let alert = UIAlertController(title: "Looking for Setting", message: "Set up for your requirment", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Add Users", style: .default, handler: { (UIAlertAction) in
            print("ok")
            
        }))
        alert.addAction(UIAlertAction(title: "Profile", style: .default, handler: { (UIAlertAction) in
            print("Lokking Profile")
            
            
        }))
        alert.addAction(UIAlertAction(title: "Log Out", style: .default, handler: { (UIAlertAction) in
            print("Log Out")
            
        }))
        alert.addAction(UIAlertAction(title: "Attendence Portal", style: .default, handler: { (UIAlertAction) in
            print("Lokking for Attendence Portal")
            
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (UIAlertAction) in
            print("Cancel the alert")
        }))
        self.present(alert, animated: true, completion: nil)
        
    }
    
        
    @IBAction func button(_ sender: Any) {
        
//        _ = ScrollViewController()
//        let scVC = storyboard?.instantiateViewController(withIdentifier: "scroll")
//        present(scVC!, animated: true, completion: nil)
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "root")
//        self.di
       // self.view.window?.rootViewController?.dismiss(animated: true, completion: nil)
        UserDefaults.standard.set(false, forKey: "Loged In")
        self.navigationController?.popToRootViewController(animated: true)
//        let vc = ViewController()
//        present(vc, animated: true, completion: nil)
        print("Button Presed")

        
        
        
    }
    

}

