//
//  secondViewController.swift
//  IntenrProject
//
//  Created by Zafar Ahmad on 30/09/19.
//  Copyright © 2019 Zafar Ahmad. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


class secondViewController: UIViewController, UITextFieldDelegate {

    
    
    let ApiURL = "http://flairvapor.com/api.attendance.com/v/index.php"
    
    var email : String!
    var password : String!
    
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var LoginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logo.layer.borderWidth = 1.0
        logo.layer.masksToBounds = false
        logo.layer.borderColor = UIColor.lightGray.cgColor
        logo.layer.cornerRadius = logo.frame.size.width/2
        logo.clipsToBounds = true
        // Do any additional setup after loading the view.
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        
        EmailTextField.delegate = self
        PasswordTextField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
 
    @IBAction func LoginButton(_ sender: Any) {
        
       
        
       
        print(email as Any,password as Any)
        
       

       if EmailTextField.text != "" && PasswordTextField.text == "1234" {
        email = EmailTextField.text
        password = PasswordTextField.text
        PutData(Email: email, Pass: password)
           
        getURl(url: ApiURL)
        }
       
        else {
            let alertController = UIAlertController(title: "Error", message: "Please Enter Valid E-Mail Address and Password", preferredStyle: .alert)

            let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in

                // Code in this block will trigger when OK button tapped.
                print("Error in Log In");

            }

            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
//    func pushValue(json: JSON) {
//
//        let cName = json["CompanyDetails"]["companyName"].string
//
//        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//
//            if segue.identifier == "go" {
//                let thirdVC = segue.destination as! thirdViewController
//                thirdVC.data = cName!
//
//
//            }
//
//
//        }
//
//
//    }
   
    
    
    func getURl(url: String) {
        
        Alamofire.request(url, method: .get).responseJSON { (response) in
            
            if response.result.isSuccess {
                let ApiResponse : JSON = JSON(response.result.value!)
                print(ApiResponse)
            }
            else {
                print("No Response From the server")
            }
            
        }
        
    }
    
    func PutData(Email: String, Pass: String) {
    
        Alamofire.request(ApiURL, method: .post, parameters: ["clientKey": "clientKey", "accessToken":"accessTokenValue", "action": "login", "requestData": [ "email": Email, "password": Pass]], encoding: JSONEncoding.default, headers: nil).responseJSON { (resfonce) in
            
            if resfonce.result.isSuccess {
                let getJason : JSON = JSON(resfonce.result.value!)
                print(JSON(resfonce.result.value!))
                print(getJason)
                UserDefaults.standard.set(true, forKey: "Loged In")
               // let thirdVC = thirdViewController()
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "GO")
                self.present(vc!, animated: true, completion: nil)
                
                
                
               

               
            }
            else {
                print("there is an error")
            }
            
            
        }
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        
        // Not found, so remove keyboard
        textField.resignFirstResponder()
        
        
        
        
        return true
        
    }
    func validateEmail(enteredEmail:String) -> Bool {
        
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: enteredEmail)
        
    }
    
}
