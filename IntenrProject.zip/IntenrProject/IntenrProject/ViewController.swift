//
//  ViewController.swift
//  IntenrProject
//
//  Created by Zafar Ahmad on 30/09/19.
//  Copyright © 2019 Zafar Ahmad. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var imageLogo: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageLogo.layer.borderWidth = 0.5
        imageLogo.layer.masksToBounds = false
        imageLogo.layer.borderColor = UIColor.lightGray.cgColor
        imageLogo.layer.cornerRadius = imageLogo.frame.size.width/2
        imageLogo.clipsToBounds = true
        
        
        
        
        
        if UserDefaults.standard.bool(forKey: "Loged In") == true {
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "GO")
            self.navigationController?.pushViewController(vc!, animated: false)
            
        }
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    

    @IBAction func loginButon(_ sender: Any) {

     // performSegue(withIdentifier: "login", sender: self)
        
    }
    
    
    
}

